﻿using IPALogger = IPA.Logging.Logger;

namespace BSPlugin1
{
    internal static class Logger
    {
        internal static IPALogger log { get; set; }
    }
}
