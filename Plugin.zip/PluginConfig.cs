﻿namespace BSPlugin1
{
    internal class PluginConfig
    {
        public bool RegenerateConfig = true;
        public string text = "";

    }
}
